import os
import csv
import webbrowser
import platform
from pystyle import Colors, Colorate, Center
from concurrent.futures import ThreadPoolExecutor

# Функция для отображения баннера
def display_banner():
    banner = """
 ____ __      __ ______  _   _  _______  _____   _____   _______  ______            __  __ 
  / __ \\ \    / /|  ____|| \ | ||__   __||_   _| / ____| |__   __||  ____|    /\    |  \/  |
 | |  | |\ \  / / | |__   |  \| |   | |     | |  | (___      | |   | |__      /  \   | \  / |
 | |  | | \ \/ /  |  __|  | . ` |   | |     | |   \___ \     | |   |  __|    / /\ \  | |\/| |
 | |__| |  \  /   | |____ | |\  |   | |    _| |_  ____) |    | |   | |____  / ____ \ | |  | |
  \___\_\   \/    |______||_| \_|   |_|   |_____||_____/     |_|   |______|/_/    \_\|_|  |_|                                                                 
                     +------------------------------------------------+
                     | Софт сделан эксклюзивно для @QVENTIS_TEAM      |
                     +------------------------------------------------+ """
    colored_banner = Colorate.Vertical(Colors.yellow_to_red, Center.XCenter(banner))
    print(colored_banner)

# Функция для поиска в файле
def search_in_file(filename, search_term):
    try:
        with open(filename, mode='r', encoding='utf-8') as file:
            if filename.endswith('.csv'):
                reader = csv.reader(file, delimiter=';')
                for row in reader:
                    if search_term in row:
                        return ';'.join(row)
            else:
                content = file.read()
                if search_term in content:
                    return content
        return None  # Если ничего не найдено
    except Exception as e:
        return f"Ошибка при обработке файла {filename}: {e}"

# Функция для параллельного поиска по файлам
def search_files(database_dir, search_term):
    results = []
    with ThreadPoolExecutor() as executor:
        # Создание списка файлов для поиска
        files = [os.path.join(database_dir, f) for f in os.listdir(database_dir) if os.path.isfile(os.path.join(database_dir, f))]
        # Параллельный поиск
        futures = {executor.submit(search_in_file, file, search_term): file for file in files}

        for future in futures:
            result = future.result()
            if result:
                results.append(f"Информация в файле {futures[future]}: {result}")
    return results

# Функция для открытия ссылки
def open_link():
    url = "https://t.me/+wTYMzFT9ev9iYWMy"
    system = platform.system()

    if system == "Linux":
        if "com.termux" in os.getenv("PREFIX", ""):
            os.system(f'am start -a android.intent.action.VIEW -d "{url}"')
        else:
            webbrowser.open(url)
    elif system == "Windows":
        webbrowser.open(url)
    else:
        pass

# Основная функция программы
def main():
    database_dir = 'database'  # Папка с базой данных
    print(f"Текущая рабочая директория: {os.getcwd()}")
    print(f"Поиск файлов в директории: {database_dir}")

    while True:
        display_banner()  # Отображение баннера
        menu = """
                                    [1] Поиск по номеру                
                                    [2] Поиск по почте        
                                    [3] Поиск по ФИО                             
                                    [4] Поиск по адресу
                                    [5] Поиск по юзерагенту
                                    [6] Узнать, какой лучший канал года
                                    [7] Выход из программы
                                   """
        colored_menu = Colorate.Vertical(Colors.yellow_to_red, Center.XCenter(menu))
        print(colored_menu)

        choice = input(Colorate.Horizontal(Colors.yellow_to_red, ("Выберите нужную функцию: "))).strip()

        if choice in ['1', '2', '3', '4', '5']:
            search_term = input(Colorate.Horizontal(Colors.yellow_to_red, ("Введите термин для поиска: "))).strip()

            # Поиск в директории
            results = search_files(database_dir, search_term)

            if results:
                for result in results:
                    print(f"\033[31m{result}\033[0m")
            else:
                print("\033[31mНичего не найдено по запросу.\033[0m")

        elif choice == '6':
            print("Премию лучший канал года получил: @QVENTIS_TEAM")
            open_link()  # Открытие ссылки на канал
        elif choice == '7':
            print("Пока! Выход из программы...")
            break
        else:
            print("Такой функции в этом софте нету")

        # Ожидание нажатия Enter перед возвратом к меню
        input("\nНажми enter, чтобы вернуться обратно в меню")

if __name__ == "__main__":
    main()
